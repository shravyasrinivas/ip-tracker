const lookupButton = document.querySelector(".lookup-button");
const ipDisplay = document.querySelector(".ip-display");
const locationDisplay= document.querySelector(".location-display");
const geoDisplay = document.querySelector('.geo-display');
const loader = document.querySelector(".loader-container")
const details = document.querySelector(".details")

lookupButton.addEventListener("click", () => {
    loader.style.display="flex";
    details.style.display="none";

    axios.get("https://ipapi.co/json/").then((response => {
        loader.style.display="none";
        details.style.display="flex";
        ipDisplay.textContent =`Ip: ${response.data.ip}`;
        
        locationDisplay.textContent = `Location: ${response.data.city}, ${response.data.region}, ${response.data.country}`;

        geoDisplay.textContent = `Geolocation : ${response.data.latitude},${response.data.longtitude}`;

    }));

});